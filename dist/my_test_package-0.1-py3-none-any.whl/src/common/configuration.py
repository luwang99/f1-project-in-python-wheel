raw_folder_path = "/mnt/offerrealizestorage/raw"
processed_folder_path = "/mnt/offerrealizestorage/processed"
presentation_folder_path = "/mnt/offerrealizestorage/presentation"